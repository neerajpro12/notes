CREATE DATABASE pqr;
SHOW CREATE DATABASE pqr;
USE pqr;
CREATE TABLE pqrs1(user int,emailid varchar(30),city varchar(20)); 
SHOW DATABASES ;
SHOW TABLES;

INSERT INTO pqrs1(user,emailid,city)VALUES('3','santosh@gmail.com','Baramati');
SELECT *from pqrs1;
SHOW TABLES;
