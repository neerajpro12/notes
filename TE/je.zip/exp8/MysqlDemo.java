import java.sql.*;

public class MysqlDemo {

    public static void main(String[] args) throws Exception {
        // step-1 load driver class
        Class.forName("com.mysql.jdbc.Driver");
        // step-2 connect to databse
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "root");
        // insert(connection, "Pranitee", "EnTC");
        // insert(connection, "Tushar", "EnTC");
        select(connection);
        // step-6 close connection
        connection.close();
    }

    public static void insert(Connection connection, String name, String department) throws Exception {
        PreparedStatement statement = connection
                .prepareStatement("INSERT INTO student (student_name, department_id) VALUES (?, ?)");// ? = placeholder
        // starting index 1
        statement.setString(1, name);
        statement.setString(2, department);
        int rows = statement.executeUpdate();
        System.out.println("Rows inserted " + rows);
    }

    public static void select(Connection connection) throws Exception {
        // step-3 prepare sql statement
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM student");// select
        // insert/update/delete
        // step-4 execute query
        ResultSet result = statement.executeQuery();
        // step-5 iterate orver result/verify updated records
        while (result.next()) {
            int id = result.getInt("student_id");
            String name = result.getString("student_name");
            String department = result.getString("department_id");
            System.out.println(id + " : " + name + " : " + department);
        }
        result.close();
    }

}