package com.example;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class LoginServlet extends HttpServlet {

    protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        if("admin".equals(username) && "secret".equals(password)) {
            HttpSession session = request.getSession();
            session.setAttribute("loggedIn", "true");
            response.sendRedirect("home.jsp");
        } else {
            PrintWriter writer = response.getWriter();
            response.setContentType("text/html");
            writer.println("Invalid credentials.");
            writer.println("<a href='index.jsp'>Back to Login</a>");
        }
    }

}

