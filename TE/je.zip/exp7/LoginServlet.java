package com.example;

import java.io.*;
import jakarta.servlet.http.*;
import jakarta.servlet.*;

public class LoginServlet extends HttpServlet  {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        try {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<h1>Server side code.</h1>");
            out.println("Username : " + request.getParameter("user"));
            out.println("Password : " + request.getParameter("pass"));
            out.close();
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        try {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<h1>Not supported.</h1>");
            out.close();
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
        }
    }

}